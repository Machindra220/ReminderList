-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 18, 2018 at 07:59 AM
-- Server version: 5.7.19
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projects`
--

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

DROP TABLE IF EXISTS `schedule`;
CREATE TABLE IF NOT EXISTS `schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `module` text NOT NULL,
  `date` date NOT NULL,
  `strtime` time NOT NULL,
  `stptime` time NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`id`, `name`, `module`, `date`, `strtime`, `stptime`) VALUES
(1, 'Exodentist', 'Updation-Arushe Clinic', '2018-05-16', '12:10:00', '12:35:00'),
(2, 'Exodentist', 'Updation-Omega Dental-Prescription Setting', '2018-05-16', '13:00:00', '13:30:00'),
(3, 'Exodentist', 'Updation-Raman Dental-Prescription Setting', '2018-05-16', '13:50:00', '14:15:00'),
(4, 'Exodentist', 'updation after- Prescription Setting-reach to office', '2018-05-16', '11:40:00', '14:45:00'),
(5, 'Exodentist', 'Raman-setup-priscription-changes-in updated version', '2018-05-16', '16:30:00', '17:55:00'),
(6, 'Exodentist', 'Smilecare dental Installation-updated version with  multiuser', '2018-05-16', '19:10:00', '20:00:00'),
(7, 'Machindra wagre', 'Gurukrupa Setup', '2018-05-16', '12:59:00', '00:00:00'),
(8, 'Exodentist', 'Raman- Setup changes in prescription', '2018-05-17', '10:15:00', '11:13:00'),
(9, 'Precitech', 'Sales Person Login - Testing', '2018-05-17', '11:23:00', '11:50:00'),
(10, 'Discussion with S.K.Sir', 'Discussion on Precitech, School ERP, and Exodentist', '2018-05-17', '11:50:00', '14:05:00'),
(11, 'School ERP', 'UI Design Shown to Mr. Dange Sir', '2018-05-17', '15:04:00', '16:20:00'),
(12, 'Exodentist', 'Gurukrupa Setup for update ', '2018-05-17', '17:15:00', '18:40:00');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
