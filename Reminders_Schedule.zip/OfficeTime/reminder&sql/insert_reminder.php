
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "projects";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 	
		
		$sql="INSERT INTO reminders (project, module, date, comp_date, time)
		VALUES
		('$_POST[project]','$_POST[module]','$_POST[date]','$_POST[comp_date]','$_POST[time]')";
		
		if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

?>