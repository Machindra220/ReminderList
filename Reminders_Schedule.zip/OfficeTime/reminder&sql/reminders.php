<?php
$db_host = 'localhost'; // Server Name
$db_user = 'root'; // Username
$db_pass = ''; // Password
$db_name = 'projects'; // Database Name

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
if (!$conn) {
	die ('Failed to connect to MySQL: ' . mysqli_connect_error());	
}

$sql = 'SELECT * 
		FROM reminders';
		
$query = mysqli_query($conn, $sql);

if (!$query) {
	die ('SQL Error: ' . mysqli_error($conn));
}
?>
<html>

		<!-- Stylesheet -->
        <link rel="stylesheet" href="css/bootstrap.css">
<head>
	<title>Daily Work Schedule</title>
	<style type="text/css">
		body {
			font-size: 15px;
			color: #343d44;
			font-family: "segoe-ui", "open-sans", tahoma, arial;
			padding: 0;
			margin: 0;
		}
		table {
			margin: auto;
			font-family: "Lucida Sans Unicode", "Lucida Grande", "Segoe Ui";
			font-size: 12px;
		}

		h1 {
			margin: 25px auto 0;
			text-align: center;
			text-transform: uppercase;
			font-size: 17px;
		}

		table td {
			transition: all .5s;
		}
		
		/* Table */
		.data-table {
			border-collapse: collapse;
			font-size: 14px;
			min-width: 537px;
		}

		.data-table th, 
		.data-table td {
			border: 1px solid #e1edff;
			padding: 7px 17px;
		}
		.data-table caption {
			margin: 7px;
		}

		/* Table Header */
		.data-table thead th {
			background-color: #508abb;
			color: #FFFFFF;
			border-color: #6ea1cc !important;
			text-transform: uppercase;
		}

		/* Table Body */
		.data-table tbody td {
			color: #353535;
		}
		.data-table tbody td:first-child,
		.data-table tbody td:nth-child(4),
		.data-table tbody td:last-child {
			text-align: right;
		}

		.data-table tbody tr:nth-child(odd) td {
			background-color: #f4fbff;
		}
		.data-table tbody tr:hover td {
			background-color: #ffffa2;
			border-color: #ffff0f;
		}

		/* Table Footer */
		.data-table tfoot th {
			background-color: #e5f5ff;
			text-align: right;
		}
		.data-table tfoot th:first-child {
			text-align: left;
		}
		.data-table tbody td:empty
		{
			background-color: #ffcccc;
		}
	</style>
</head>

	<header>
	
</div>
<!--	<div class="col-md-12">  -->
	<div class="row">
	<div class="col-md-2"><br/>
	<img src="images/logo.png"  alt="Increpe"  width="200" height="59">
	
	</div>
	<div class="col-md-1" id="parent">
	<img src="images/boy.png"  alt=""  width="90" height="194">
	
	</div>
	<div class="col-md-6"><br/>
	<!--<a href="index.html"></button><b> &nbsp &nbsp Add Schedule</b></button></a>
	<img src="images/boy.png"  alt=""  width="70" height="164" data-bgposition="80% center">
	<a href="index.html" class="btn-one">Back</a>  -->
	<h2><u>Increpe Technologies Pvt. Ltd. </u></h2>
	<h3>Daily Work schedule</h3>
	<a href="index.html"></button><b> &nbsp &nbsp Add Schedule<img src="images/add.png"  alt=""  width="34" height="34"></b></button></a>
	<a href="reminder.html"></button><b> &nbsp &nbsp Add Reminder<img src="images/add.png"  alt=""  width="34" height="34"></b></button></a>
<div id="popup" style="display: none">Fill your todays Work?</div>
	<!--	<caption class="title">Project Working Schedule</caption>   -->
	</div>
	<div class="col-md-3" id="parent">
	<img src="images/girl3.png"  alt=""  width="90" height="194">
	</div>
	</div>
<!--	</div> -->
	
	</header>
<body>
	<br/>
	<div class="col-md-12">
	<div class="col-md-1">
	
	</div>
	<div class="col-md-10">
		<table class="data-table">
		<thead>
			<tr>
				<th>NO</th>
				<th>PROJECT NAME</th>
				<th>MODULE</th>
				<th>DATE </th>
				<th>Completion Date</th>
				<th>Completion Time</th>
			</tr>
		</thead>
		<tbody>
		<?php
		$no 	= 1;
		$total 	= 0;
		
		
		
		while ($row = mysqli_fetch_array($query))
		{
			
			//$amount  = $row['amount'] == 0 ? '' : number_format($row['amount']);
			echo '<tr>
					<td>'.$no.'</td>
					<td>'.$row['Project'].'</td>
					<td>'.$row['module'].'</td>
					<td>'. date('F d, Y', strtotime($row['date'])) . '</td>
					<td>'. $row['comp_date'] .'</td>
					<td>'. $row['time'] .'</td>
				</tr>';
			//	echo '<tr> <br/></tr>';
			//$total += $row['amount'];
			$no++;
		}?>
		</tbody>
		<tfoot>
			<tr>
			<!--	<th colspan="4">TOTAL</th>
				<th><?=number_format($total)?></th>  -->
			</tr>
		</tfoot>
	</table>
	</div>
	<div class="col-md-1">
	
	</div>
	</div>
	<footer><br/><hr/>
	<div class="col-md-12">
	<div class="row">
	<div class="col-md-1"></div>
	<div class="col-md-1">
	<img src="images/boy3.png"  alt=""  width="90" height="194" center" align="center";>
	</div>
	<div class="col-md-6">
	<p align="center";> <b> Add this page link to your bookmark bar so that you never miss it.</b>  </p>
	<p align="center";>Designed For: Increpe Technologies Pvt. Ltd.</p>
	</div>
	<div class="col-md-2">
	<img src="images/girl2.png"  alt=""  width="90" height="194" center" align="right";>
	</div>
	</div>
	</div>
	</footer>
	<script>
	var e = document.getElementById('parent');
e.onmouseover = function() {
  document.getElementById('popup').style.display = 'block';
}
e.onmouseout = function() {
  document.getElementById('popup').style.display = 'none';
}
	</script>
</body>
</html>