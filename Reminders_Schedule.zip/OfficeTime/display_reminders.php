
<meta name="viewport" content="width=device-width, initial-scale=1">

<?php
$db_host = 'localhost'; // Server Name
$db_user = 'root'; // Username
$db_pass = ''; // Password
$db_name = 'projects'; // Database Name

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
if (!$conn) {
	die ('Failed to connect to MySQL: ' . mysqli_connect_error());	
}

$sql = 'SELECT * 
		FROM reminders ORDER BY date DESC';
		
$query = mysqli_query($conn, $sql);

if (!$query) {
	die ('SQL Error: ' . mysqli_error($conn));
}
?>
<html>

		<!-- Stylesheet -->
        <link rel="stylesheet" href="css/bootstrap.css">
		<link rel="icon" href="images/favicon.png">
    <style>
    #myBtn {
		  display: none;
		  position: fixed;
		  bottom: 20px;
		  right: 20px;
		  z-index: 99;
		  font-size: 18px;
		  border: none;
		  outline: none;
		  background-color: #70cdea;
		  color: white;
		  cursor: pointer;
		  padding: 15px;
		  border-radius: 4px;
		}
		
		#myBtn:hover {
		  background-color: mediumseagreen;
		}
				<!-- end of top bar address on mouse hover -->	
		</style>
<head>
	<title>Reminders Schedule</title>
	<style type="text/css">
		body {
			font-size: 15px;
			color: #343d44;
			font-family: "segoe-ui", "open-sans", tahoma, arial;
			padding: 0;
			margin: 0;
            
		}
		table {
			margin: auto;
			font-family: "Lucida Sans Unicode", "Lucida Grande", "Segoe Ui";
			font-size: 12px;
           
		}

		h1 {
			margin: 25px auto 0;
			text-align: center;
			text-transform: uppercase;
			font-size: 17px;
		}

		table td {
			transition: all .5s;
		}
		
		/* Table */
		.data-table {
			border-collapse: collapse;
			font-size: 14px;
			min-width: 537px;
		}

		.data-table th, 
		.data-table td {
			border: 1px solid #e1edff;
			padding: 7px 17px;
		}
		.data-table caption {
			margin: 7px;
		}

		/* Table Header */
		.data-table thead th {
			background-color: #108abb;
			color: #FFFFFF;
			border-color: #6ea1cc !important;
			text-transform: uppercase;
		}

		/* Table Body */
		.data-table tbody td {
			color: #353535;
		}
		.data-table tbody td:first-child,
		.data-table tbody td:nth-child(4),
		.data-table tbody td:last-child {
			text-align: right;
		}

		.data-table tbody tr:nth-child(odd) td {
			background-color: #e9ebeb;
		}
		.data-table tbody tr:hover td {
			background-color: #ffffff;
			border-color: #ffff0f;
		}

		/* Table Footer */
	/*	.data-table tfoot th {
			background-color: red;
			text-align: right;
		}
		.data-table tfoot th:first-child {
			text-align: left;
		}
		.data-table tbody td:empty
		{
			background-color: #ffcccc;
		}  */
	</style>
    
   
<style>
body, html {
    height: 100%;
    font-family: Arial, Helvetica, sans-serif;
}

* {
    box-sizing: border-box;
}

.bg-img {
    /* The image used */
    background-image: url("images/formbg8.jpg");

    min-height: 1080px;

    /* Center and scale the image nicely */
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
}

/* Add styles to the form container */
.container {
	color: sandybrown;  /* text color  */
    position: absolute;
    left: 0;
    margin: 20px;
    max-width: 1399px;  /* background color  */
    padding: 16px;
    background-color: green;
    opacity:0.5;
}

/* Add styles to the form container */
.container2 {
	color: black;  /* text color  */
    position: absolute;
    left: 0;
    margin: 20px;
    max-width: 350px;
    padding: 16px;
    background-color: white;
    opacity:0.6;
}

/* Full-width input fields */
input[type=text], input[type=textbox], input[type=date], input[type=time] {
    width: 60%;
    padding: 15px;
    margin: 5px 0 22px 0;
    border: none;
    background: #a9f1f1;
}

input[type=text]:focus, input[type=textbox]:focus, input[type=date]:focus, input[type=time]:focus {
    background-color: #ddd;
    outline: none;
}

/* Set a style for the submit button */
    /*
.btn {
    background-color: #4CAF50;
    color: white;
    padding: 10px 25px;
    border: none;
    cursor: pointer;
    width: 33%;
    opacity: 0.9;
}
*/
.btn:hover {
    opacity: 1;
}
</style>

    
    
</head>

	<header>
	
	</header>
<body>
    <script>
			// When the user scrolls down 20px from the top of the document, show the button
			window.onscroll = function() {scrollFunction()};

			function scrollFunction() {
				if (document.body.scrollTop > 70 || document.documentElement.scrollTop > 70) {
					document.getElementById("myBtn").style.display = "block";
				} else {
					document.getElementById("myBtn").style.display = "none";
				}
			   
			}

			// When the user clicks on the button, scroll to the top of the document
			function topFunction() {
			 
				 $('html, body').animate({scrollTop:0}, 'slow');
			}
	</script>
    
    <script src="https://code.jquery.com/jquery-1.10.2.js"></script>

	<button onclick="topFunction()" id="myBtn" title="Go to top">Top</button>
    
	<br/>
    
<div class="bg-img">
    <div class="container">
	<div class="col-md-12">
	<h3 style="text-align:center">Working Project Schedule</h3>
	<h4 style="text-align:right"><a href="index.html"><b style="color:yellow"> Add Schedule </b> </a></h4>
	<div class="col-md-12">
	
		<table class="data-table">
		<thead>
			<tr>
				<th>NO</th>
				<th>PROJECT NAME</th>
				<th>MODULE</th>
                <th>TASK</th>
				<th>Schedule DATE </th>
				<th>Schedule Time</th>
				<th>Completion Time</th>
			</tr>
		</thead>
		<tbody>
		<?php
		$no 	= 1;
		$total 	= 0;
		
		
		
		while ($row = mysqli_fetch_array($query))
		{
			
			//$amount  = $row['amount'] == 0 ? '' : number_format($row['amount']);
			echo '<tr>
					<td>'.$no.'</td>
					<td>'.$row['pname'].'</td>
					<td>'.$row['pmodule'].'</td>
                    <td>'.$row['ptask'].'</td>
					<td>'. date('F d, Y', strtotime($row['scheduledt'])) . '</td>
					<td>'. $row['scheduletm'] .'</td>
					<td>'. $row['ctime'] .'</td>
				</tr>';
			//	echo '<tr> <br/></tr>';
			//$total += $row['amount'];
			$no++;
		}?>
		</tbody>
		<tfoot>
			<tr>
			<!--	<th colspan="4">TOTAL</th>
				<th><?=number_format($total)?></th>  -->
			</tr>
		</tfoot>
	</table>
	</div>
	
	</div>
        </div>
        </div>
	
	
</body>
</html>