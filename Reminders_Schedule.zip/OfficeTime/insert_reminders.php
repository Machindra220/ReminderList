
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "projects";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 	
		
		$sql="INSERT INTO reminders (pname, pmodule, ptask, scheduledt, scheduletm, ctime)
		VALUES
		('$_POST[name]','$_POST[pmodule]','$_POST[ptask]','$_POST[scheduledt]','$_POST[scheduletm]','$_POST[ctime]')";
		
		if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

?>